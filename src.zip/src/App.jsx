import React from 'react'
import Navbar from './32.MovieProject/Layout/Navbar/Navbar'
import Footer from './32.MovieProject/Layout/Footer/Footer'
import Home from './32.MovieProject/Pages/Home/Home'
import Trending from  './32.MovieProject/Pages/Trending/Trending'
import {BrowserRouter,Routes,Route} from 'react-router-dom'

const App = () => {
  return (
    <div>
     
       <BrowserRouter>
        <Navbar />
       <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/trending' element={<Trending />} />
         </Routes>
        <Footer />
       </BrowserRouter> 
    </div>
  )
}

export default App