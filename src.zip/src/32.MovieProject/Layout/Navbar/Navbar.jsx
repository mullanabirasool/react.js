import React from 'react'
import './Navbar.scss'

const Navbar = () => {

  return (
    <div className='navbar'>
    <div className="navbar-left">
        <p>Ahaa</p>
    </div>
    <div className="navbar-right">
        <li><input type="text" placeholder='Search' /></li>
        <li>Home</li>
        <li>Trending</li>
        <li>Upcoming</li>
        <li>Contact</li>
    </div>
    </div>
  )
}

export default Navbar