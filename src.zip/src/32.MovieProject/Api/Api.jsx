import axios from "axios";

const baseURL=import.meta.env.VITE_BASE_URL;
const api_key =import.meta.env.VITE_API_KEY;


 export  async function fetchPopularMovies() {
                const response = await axios.get(`${baseURL}movie/popular?language=en-US`,{
                    params:{
                        api_key:api_key,
                        page:1
                    }  
                } )
                return response.data.results
             }
 export async function fetchTrendingMovies() {
      const response = await axios.get(`${baseURL}/trending/all/day?language=en-US`,{
            params:{
                api_key:api_key,
                page:1
            }
      })
    return response.data.results
 }           