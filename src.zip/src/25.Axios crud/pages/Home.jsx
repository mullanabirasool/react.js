import axios from 'axios'
// import './Home.css'
import { useEffect, useState } from 'react'
import { useNavigate,Link } from 'react-router-dom'

const Home = () => {
    const[data,setData]=useState([])
    const navigate = useNavigate()

    useEffect(()=>{
    axios.get('http://localhost:3000/users')
       .then(respose=>setData(respose.data)) 
       
    },[])


    function handleDelete(id){
        axios.delete(`http://localhost:3000/users/${id}`)
        .then(()=> setData(data.filter(users => item.id !== id )))
        .catch(err => console.error("Error fetching users:",err))  
    }

  return (

    <div className='home'>

    <h1>AXIOS CRUD</h1>

   
 <Link to={'/create'}><button>Add +</button></Link>
 
    <table border='1px' cellPadding='10px' cellSpacing='10px'>
         <thead>
            <tr>
                <td><b>Id</b></td>
                <td><b>Name</b></td>
                <td><b>Email</b></td>
                <td><b>Action</b></td>
            </tr>
        </thead> 
    
       <tbody>
  {
    data.map((item, index) => {
      return (
        <tr key={item.id}>
          <td>{item.id}</td>
          <td>{item.name}</td>
          <td>{item.email}</td>
          <td>
            <Link to={`/read/${item.id}`}><button>Read</button></Link>
            <Link to={`/update/${item.id}`}><button>Update</button></Link>
            <button onClick={() => handleDelete(item.id)}>Delete</button>
          </td>
        </tr>
      )
    })
  }
</tbody>

        <tfoot>

        </tfoot>
    </table>

    </div>
  )
}

export default Home